package com.anglab.toontaku;

import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import android.app.ListActivity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ListViewer extends ListActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	static class ListAdapterWithButton<T> extends BaseAdapter {
		private final LayoutInflater mInflater;
		private final List<Map> array;
	    private final Context mContext;

		public ListAdapterWithButton(final Context context, final List<Map> array) {
			this.mContext = context;
			this.mInflater = LayoutInflater.from(context);
			this.array = array;
		}

		@Override
		public int getCount() { return array.size(); }

		@Override
		public String getItem(int position) { return (String)array.get(position).get("NAME"); }

		@Override
		public long getItemId(int position) { return position; }

		class ViewHolder {
			TextView label;
			Button btn_list_01;
			ImageView img_site;
			ImageView img_new;
			ImageView img_fin;
			RelativeLayout lay_mm;
			WebView web_thumb;
			CheckBox chk_list_02;
			TextView txt_section;
		}

		@SuppressWarnings("deprecation")
		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			ViewHolder holder;
			final MainActivity vMainActivity = (MainActivity) mContext;

			if ( convertView == null ) {
				convertView = mInflater.inflate(R.layout.list_one_row, null);
				holder = new ViewHolder();
				holder.label     = (TextView) convertView.findViewById(R.id.txt_title);
				holder.btn_list_01 = (Button) convertView.findViewById(R.id.btn_list_01);
				holder.img_site  = (ImageView) convertView.findViewById(R.id.img_site);
				holder.img_new   = (ImageView) convertView.findViewById(R.id.img_new);
				holder.img_fin   = (ImageView) convertView.findViewById(R.id.img_fin);
				holder.lay_mm    = (RelativeLayout) convertView.findViewById(R.id.lay_mm);
				holder.web_thumb = (WebView) convertView.findViewById(R.id.web_thumb);
				holder.chk_list_02 = (CheckBox) convertView.findViewById(R.id.chk_list_02);
				holder.txt_section = (TextView) convertView.findViewById(R.id.txt_section);
				convertView.setTag(holder);
			} else {
				holder = (ViewHolder) convertView.getTag();
			}
			String vName = fn_getList(position, "NAME");
			holder.label.setText(vName); // ����Ʈ ����

			// �ڷᰡ ���� = �˻��� ����� �����ϴ�
			if ( vMainActivity.getResources().getString(R.string.str_noSearchData).equals(vName)
			  && array.size() == 1 ) {
				holder.lay_mm.setBackgroundColor(Color.WHITE);
				holder.label.setTextColor(0xFF333333);
				holder.btn_list_01.setVisibility(View.GONE);
				holder.img_new.setVisibility(View.GONE); 
				holder.img_fin.setVisibility(View.GONE); 
				holder.img_site.setVisibility(View.GONE);
				holder.chk_list_02.setVisibility(View.GONE);
				holder.web_thumb.setVisibility(View.GONE);
				holder.txt_section.setVisibility(View.GONE);
				return convertView;
			}

			final String vMode = vMainActivity.fn_getMode();
			/********** ����ó�� **********/
			if ( "2".equals(vMode) || "4".equals(vMode) ) {
				String vSectionWord = vMainActivity.fn_sectionWordsEmpty(position);
				if ( "".equals(vSectionWord) ) {
					holder.txt_section.setVisibility(View.GONE);
				} else {
					holder.txt_section.setText(vSectionWord);
					holder.txt_section.setVisibility(View.VISIBLE);
				}
			} else {
				holder.txt_section.setVisibility(View.GONE);
			}
			/********************/

			/********** ��ĥó��, new ó�� **********/
			// vTF1:24�ð� �̳� ������Ʈ �Ǿ��°�, vTF2:���� �Ⱥ� �ֽ�ȭ�� �ִ°�
			String vLstUpdDh = fn_getList(position, "LST_UPD_DH");

			boolean vTF1 = !"".equals(vLstUpdDh) && ( vMainActivity.gv_isNewDate.compareTo(vLstUpdDh) < 0 );
			boolean vTF2 = ( !"".equals(fn_getList(position, "LST_VIEW_NO")) && !"".equals(fn_getList(position, "MAX_NO")) )
					    && !fn_getList(position, "MAX_NO").equals(fn_getList(position, "LST_VIEW_NO"));

			if ( vTF2 ) {
				holder.lay_mm.setBackgroundColor(Color.WHITE);
				holder.label.setTextColor(0xFF33BB77);
			} else {
				holder.lay_mm.setBackgroundColor(0xFFF4F4F4);
				holder.label.setTextColor(0xFF333333);
			}
			holder.img_new.setVisibility(vTF1? View.VISIBLE : View.GONE); // new image icon visible
			/********************/

			/********** �Ϸ� ������ **********/
			if ( "Y".equals(fn_getList(position, "COMP_YN")) ) {
				holder.img_fin.setVisibility(View.VISIBLE);
			} else {
				holder.img_fin.setVisibility(View.GONE);
			}
			/********************/

			/********** ����Ʈ ����� **********/
			String vSite = fn_getList(position, "SITE");
			int vDrawable = -1;
			if ( "naver".equals(vSite) ) vDrawable = R.drawable.ic_naver;
			else if ( "nate".equals(vSite) ) vDrawable = R.drawable.ic_nate;
			else if ( "daum".equals(vSite) ) vDrawable = R.drawable.ic_daum;
			else if ( "naver_b".equals(vSite) ) vDrawable = R.drawable.ic_naver_b;
			else if ( "daum_l".equals(vSite)  ) vDrawable = R.drawable.ic_daum_l;
			else if ( "kakao".equals(vSite)  ) vDrawable = R.drawable.ic_kakao;

			if ( vDrawable == -1 ) {
				holder.img_site.setVisibility(View.GONE);				
			} else {
				holder.img_site.setVisibility(View.VISIBLE);
				holder.img_site.setBackgroundResource(vDrawable);
				(holder.img_site.getBackground()).setAlpha(400); // ������ ����
			}
			/********************/

			/********** ��ư ������ ó�� **********/
			boolean vThumbTF = true;

			holder.web_thumb.setVisibility(View.VISIBLE);
			holder.chk_list_02.setVisibility(View.GONE);
			
			if ( "0".equals(vMode) ) { // ���������
				holder.btn_list_01.setBackgroundResource(R.drawable.ic_sub_b);
			} else if ( "1".equals(vMode) ) { // ����Ʈ
				vThumbTF = false;
				holder.btn_list_01.setVisibility(View.GONE);
				holder.web_thumb.setVisibility(View.GONE);
				holder.img_site.setVisibility(View.GONE);
			} else if ( "2".equals(vMode) || "4".equals(vMode) ) { // ������� / �˻�
				if ( "Y".equals(fn_getList(position, "MY_INQ_YN")) ) {
					holder.btn_list_01.setVisibility(View.GONE);
				} else { // �� ���� ����Ʈ�� ������ �߰� ��ư
					holder.btn_list_01.setVisibility(View.VISIBLE);
					holder.btn_list_01.setBackgroundResource(R.drawable.ic_add_b);
				}
			} else if ( "3".equals(vMode) ) { // ȸ������
				holder.btn_list_01.setVisibility(View.GONE);
			} else if ( "5".equals(vMode) ) { // ����
				vThumbTF = false;
				holder.btn_list_01.setVisibility(View.GONE);
				holder.web_thumb.setVisibility(View.GONE);
				holder.img_site.setVisibility(View.GONE);
				holder.img_new.setVisibility(View.GONE);
				
				if ( "CheckBox".equals(fn_getList(position, "SEL_MODE")) ) {
					holder.chk_list_02.setVisibility(View.VISIBLE);
					holder.chk_list_02.setChecked("Y".equals(fn_getList(position, "SET_VALUE")));
					holder.chk_list_02.setOnCheckedChangeListener(new OnCheckedChangeListener() {
						@Override
						public void onCheckedChanged(CompoundButton arg0, boolean arg1) {
							vMainActivity.fn_checkOnClick(position, arg1);
						}
					});
				}
			}
			/****************************************/

			/********** ����� ó�� **********/
			if ( vThumbTF ) { // ����� ���Ⱑ true�̸�
				if ( "Y".equals(vMainActivity.fn_getSetting("THUMB_YN")) ) {
					String vSource = "<body leftmargin=0 topmargin=0 marginwidth=0 marginheight=0><img src = '" + vMainActivity.fn_getUrl(position) + "' width=100% height=100%></body>";
					holder.web_thumb.loadData(URLEncoder.encode(vSource).replaceAll("\\+"," "), "text/html", "UTF-8");
				} else {
					holder.web_thumb.loadUrl("file:///android_asset/htm_imgview.htm");
				}
			}
			/********************/

			holder.lay_mm.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					vMainActivity.fn_listOnClick(position);
				}
			});

			holder.btn_list_01.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if ( "0".equals(vMode) ) { // ���������
						vMainActivity.fn_delMyList(fn_getList(position, "ID_SEQ"));
					} else {
						vMainActivity.fn_insMyList(fn_getList(position, "ID_SEQ"));
					}
				}
			});

			holder.btn_list_01.setOnTouchListener(new OnTouchListener() {
				public boolean onTouch(View v, MotionEvent event) {
					vMainActivity.onTouch(v, event);
					return false;
				}
			});

			return convertView;
		}

		public String fn_getList(int pPosition, String pTag) {
			if ( getCount() <= pPosition && 0 > pPosition ) return "";
			if ( !array.get(pPosition).containsKey(pTag) ) return "";
			String vReturn = (String) array.get(pPosition).get(pTag);
			if ( vReturn == null || vReturn.trim().length() == 0 ) vReturn = "";
			return vReturn;
		}
	}
}