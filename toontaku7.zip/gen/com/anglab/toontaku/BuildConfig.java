/** Automatically generated file. DO NOT MODIFY */
package com.anglab.toontaku;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}